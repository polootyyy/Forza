using Polootyyy.Models;

namespace Polootyyy.Services;

public class CrcBypassEngine
{
    private readonly MemoryService _memory;
    private readonly SignatureService _signature;
    private readonly Dictionary<string, (nint Address, byte[] Original)> _patches = new();
    private bool _crcBypassActive;
    private System.Timers.Timer? _crcTimer;

    public bool IsBypassActive => _crcBypassActive;
    public event Action<string, LogLevel>? OnLog;

    // Real CRC bypass signatures from StandForFH6 / MiracleDLC
    private const string CrcCheckSignature = "48 8B 05 ?? ?? ?? ?? 48 85 C0 74 ?? 8B 88 ?? ?? ?? ??";
    private const string ProfileHookSignature = "48 89 5C 24 ?? 48 89 6C 24 ?? 48 89 74 24 ?? 57 48 83 EC ?? 48 8B 05";

    public CrcBypassEngine(MemoryService memory, SignatureService signature)
    {
        _memory = memory;
        _signature = signature;
    }

    public bool Initialize()
    {
        if (!_memory.IsAttached) return false;

        try
        {
            // Find and patch CRC check
            var crcAddr = FindCrcCheck();
            if (crcAddr != nint.Zero)
            {
                PatchCrcCheck(crcAddr);
                OnLog?.Invoke("🛡️ CRC check bypassed", LogLevel.Success);
            }
            else
            {
                OnLog?.Invoke("⚠️ CRC check pattern not found - may already be patched", LogLevel.Warning);
            }

            // Find and hook profile checks
            var profileAddr = FindProfileHook();
            if (profileAddr != nint.Zero)
            {
                PatchProfileHook(profileAddr);
                OnLog?.Invoke("🔧 Profile hooks patched", LogLevel.Success);
            }

            // Start CRC timer to keep bypass alive
            StartCrcTimer();

            _crcBypassActive = true;
            return true;
        }
        catch (Exception ex)
        {
            OnLog?.Invoke($"CRC bypass init failed: {ex.Message}", LogLevel.Error);
            return false;
        }
    }

    private nint FindCrcCheck()
    {
        return _signature.FindPattern("ForzaHorizon6.exe", CrcCheckSignature);
    }

    private nint FindProfileHook()
    {
        return _signature.FindPattern("ForzaHorizon6.exe", ProfileHookSignature);
    }

    private void PatchCrcCheck(nint address)
    {
        var original = _memory.ReadBytes(address, 7);
        _patches["CrcCheck"] = (address, original);

        // xor eax, eax; ret (bypass CRC check entirely)
        byte[] patch = { 0x31, 0xC0, 0xC3 };
        _memory.WriteProtectedBytes(address, patch);
    }

    private void PatchProfileHook(nint address)
    {
        var original = _memory.ReadBytes(address, 8);
        _patches["ProfileHook"] = (address, original);

        // NOP the profile hook check
        _memory.WriteNop(address, 8);
    }

    private void StartCrcTimer()
    {
        _crcTimer = new System.Timers.Timer(5000); // Check every 5 seconds
        _crcTimer.Elapsed += (_, _) =>
        {
            if (!_memory.IsAttached)
            {
                StopCrcTimer();
                return;
            }
            EnsureCrcBypass();
        };
        _crcTimer.AutoReset = true;
        _crcTimer.Start();
    }

    private void EnsureCrcBypass()
    {
        try
        {
            foreach (var (name, (addr, _)) in _patches)
            {
                // Verify patch is still in place
                var current = _memory.ReadBytes(addr, name == "CrcCheck" ? 3 : 8);
                if (name == "CrcCheck")
                {
                    if (current[0] != 0x31 || current[1] != 0xC0 || current[2] != 0xC3)
                    {
                        byte[] patch = { 0x31, 0xC0, 0xC3 };
                        _memory.WriteProtectedBytes(addr, patch);
                    }
                }
            }
        }
        catch { /* silently continue */ }
    }

    public void StopCrcTimer()
    {
        _crcTimer?.Stop();
        _crcTimer?.Dispose();
        _crcTimer = null;
    }

    public void RestoreAll()
    {
        foreach (var (name, (addr, original)) in _patches)
        {
            _memory.WriteProtectedBytes(addr, original);
            OnLog?.Invoke($"Restored: {name}", LogLevel.Info);
        }
        _patches.Clear();
        _crcBypassActive = false;
        StopCrcTimer();
    }

    public void Dispose()
    {
        RestoreAll();
    }
}
